/**
 * Java
 * 
 * Copyright 2011-2012 IS2T. All rights reserved.
 * For demonstration purpose only.
 * IS2T PROPRIETARY. Use is subject to license terms.
 */
package com.is2t.examples.edc.hello;


/**
 * Prints the message "Hello World !"
 */
public class HelloWorld {
	
	public static void main(String[] args) {
		System.out.println("Hello World !");
	}
	
}

